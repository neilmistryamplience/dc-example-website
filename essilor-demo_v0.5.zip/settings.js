module.exports = {
    cms: "https://c1.adis.ws",
    cmsAccount: "essilordemo",
    sitemap: [{
            route: "/",
            layout: "landing",
            slots: {
                "content": "7e5a30a5-3b92-48bb-9e49-3765e1af1314"
            }
        },
        {
            route: "/contactlenses",
            layout: "landing",
            slots: {
                "content": "ede4c53e-12a0-40e8-882f-ab292f60a900"
            }
        },
        {
            route: "/glasses",
            layout: "landing",
            slots: {
                "content": "04b17fa1-f492-401a-bc49-68b66ccbb6a9"
            }
        },
        {
            route: "/sunglasses",
            layout: "landing",
            slots: {
                "content": "7e952515-8f2a-4535-a863-7b96ccb1e626"
            }
        },
        {
            route: "/eyecare",
            layout: "landing",
            slots: {
                "content": "76f6ef64-6fb2-4a65-b510-eb3e80374264"
            }
        },
        {
            route: "/solutions",
            layout: "landing",
            slots: {
                "content": "5db62a63-00dc-4fe4-8083-11f5941135be"
            }
        },
        ,
        {
            route: "/helpandnews",
            layout: "landing",
            slots: {
                "content": "7e6e0cc9-e103-4d85-97fa-0dcce6240a9d"
            }
        }
    ]
};